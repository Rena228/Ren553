# Pbuni realezatsiya qilamiz, hozircha toxtatib qoydim
