<? session_start();

const API_KEY = '5569938176:AAGsk8iEOeXDlUH-PlWcVvDKa_ry32J44NU';

$system_pass = "123";
$logging = true; //false
$work_folder = str_replace("app.php", "", $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST']."".$_SERVER['REQUEST_URI']);
