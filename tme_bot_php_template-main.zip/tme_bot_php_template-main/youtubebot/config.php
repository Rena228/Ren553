<? session_start();

const API_KEY = 'tgram api token botfatherdan oalsiz';
const YOUTUBE_API_KEY = 'Youtubedan api key oling';

$system_pass = "123";
$logging = true; //false

