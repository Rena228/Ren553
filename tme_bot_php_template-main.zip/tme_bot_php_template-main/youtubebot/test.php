<? 
require_once "config.php";
require_once "funcs.php";
dump(youtuber("song"));
// echo file_get_contents("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=50&key=AIzaSyCsOAmPXGGLtDga12IvarWMMVE78gS2rUU&q=info");

